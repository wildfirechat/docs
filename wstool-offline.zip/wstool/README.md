# WebSocket 在线调试工具

方便的进行WebSocket调试 支持收发包自动格式化Json 收发消息自动清空

## 如何使用

下载后打开 wstool.html 即可使用

## 说明
本目录下的代码拷贝自[wstool](https://github.com/easy-swoole/wstool)
